package Junit.Junit;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

 class test {

    public int add(int a, int b) {
        return a + b;
    }
}
